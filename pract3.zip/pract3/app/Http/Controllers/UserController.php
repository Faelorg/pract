<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function Auth(Request $request)
    {
        $credentials = $request->validate([
            'login' => ['required'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials)) {
            return redirect('/posters');
        }

        return view('AuthView', ['error'=>'Неверный логин или пароль']);
    }

    public function Reg(Request $request)
    {
        $credentials = $request->validate([
            'name' => ['required'],
            'surname' => ['required'],
            'patronymic' => [],
            'email' => ['required', 'email'],
            'login' => ['required'],
            'password' => ['required'],
            'rules' => ['required'],
        ]);

        $user = new User();

        $user->name = $credentials["name"];
        $user->surname = $credentials["surname"];
        $user->patronymic = $credentials["patronymic"];
        $user->email = $credentials["email"];
        $user->login = $credentials["login"];
        $user->password = Hash::make($credentials["password"]);
        $user->rules = true;
        $user->is_admin = false;
        $user->saveOrFail();
        $cart = new Cart();
        $cart->id_user = $user->id;
        $cart->count = 0;
        $cart->cost = 0;
        $cart->save();
        try {

        } catch (\Throwable $th) {
            return view('RegView', ['error_text'=>'Такой пользователь уже зарегистрирован']);
        }

        if (Auth::attempt(['login'=>$credentials["login"], 'password'=>$credentials["password"]])) {
            return redirect('/posters');
        }
    }

    public function Logout(){
        auth()->logout();
        return redirect('/');
    }
}
