<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\Genre;
class EventController extends Controller
{
    public function Slider()
    {
        $events = Event::orderBy('created_at')->get();
        return view('AboutView', ['events'=> $events]);
    }
    public function GetAll(Request $request)
    {
        if (isset($request->sort) && isset($request->filter)) {
            if ($request->sort!="null") {
                $events = Event::orderBy($request->sort)->get();
            }

            if ($request->filter!="null") {
                $events = Genre::find($request->filter)->events()->get();
            }

            if ($request->filter!="null" && $request->sort!="null") {
                $events = Genre::find($request->filter)->events()->orderBy($request->sort)->get();
            }

            if($request->sort=="null"&&$request->filter=="null"){
                $events = Event::orderBy('created_at')->get();
            }
        }
        else{
            $events = Event::orderBy('created_at')->get();
        }

        return view('PosterView', ['events'=>$events,'genres'=>Genre::all()]);
    }

    public function GetById($id)
    {
        $event = Event::find($id);

        return view('PostView', ['event'=>$event,'genres'=>Genre::all()]);

    }

    public function Create(Request $request){
        $credentials = $request->validate([
            'tittle' => ['required'],
            'date' => ['required','date'],
            'age' => ['required'],
            'cost' => ['required'],
            'count' => ['required'],
            'id_genre' => ['required'],
            'image' => 'required|file|mimes:png,jpg,jpeg|max:2048'
        ]);

        $event = new Event();
        $event->tittle = $credentials['tittle'];
        $event->date = $credentials['date'];
        $event->age = $credentials['age'];
        $event->cost = $credentials['cost'];
        $event->count = $credentials['count'];
        $event->id_genre = $credentials['id_genre'];
        $event->save();
        $request->image->move(public_path('media/images'), $event->id.'.jpg');

        return redirect('/posters');
    }

    public function CreateView() {
        return view('CreateEventView',['genres'=>Genre::all()]);
    }

    public function Update($id, Request $request) {
        $credentials = $request->validate([
            'tittle' => ['required'],
            'date' => ['required','date'],
            'age' => ['required'],
            'cost' => ['required'],
            'id_genre' => ['required'],
        ]);

        $event = Event::find($id);
        $event->tittle = $credentials['tittle'];
        $event->date = $credentials['date'];
        $event->age = $credentials['age'];
        $event->cost = $credentials['cost'];
        $event->id_genre = $credentials['id_genre'];
        $event->save();
        return redirect('/posters');
    }

    public function UpdateView($id) {
        $event = Event::find($id);
        return view('CreateEventView',['event'=>$event,'genres'=>Genre::all()]);
    }

    public function Delete($id) {
        Event::find($id)->delete();
        return redirect('/posters');
    }


}
