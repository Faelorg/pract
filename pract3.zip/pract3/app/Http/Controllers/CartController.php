<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Event;
use App\Models\Cart;
use App\Models\Order;
use App\Models\CartEvent;

class CartController extends Controller
{
    public function GetAll()
    {
        $user = auth()->id();

        $cart = Cart::where(['id_user'=>$user])->first();

        $cartevents = CartEvent::where(['id_cart'=>$cart->id])->get();

        $events=[];

        foreach ($cartevents as $cartevent) {
            $events[] = Event::find($cartevent->id_event);
        }

        return view('CartView', ['cart'=>$cart,'events'=>$events]);
    }

    public function AddToCart($id)
    {
        $user = auth()->id();

        $cart = Cart::where(['id_user'=>$user])->first();
        $cart->count+=1;
        $cartevent = new CartEvent();
        $event = Event::find($id);
        $cartevent->id_user = $user;
        $cartevent->id_cart = $cart->id;
        $cartevent->id_event = $event->id;
        $cartevent->save();
        $cart->cost+=$event->cost;

        $cart->save();
        $event->count -= 1;
        $event->save();
        return redirect('/posters');
    }

    public function RemoveToCart($id)
    {
        $user = auth()->id();

        $cart = Cart::where(['id_user'=>$user])->first();
        $cart->count-=1;
        $event = Event::find($id);
        $cartevent = CartEvent::where(['id_user'=>$user, 'id_event'=>$id, 'id_cart'=>$cart->id])->first();
        $cartevent->delete();
        $cart->cost-=$event->cost;

        $event->count += 1;
        $cart->save();
        $event->save();
        return redirect('/posters');
    }

    public function CreateOrder($id)
    {
        $user = auth()->id();

        $cart = Cart::find($id);
        $order = new Order();

        $order->id_user = $user;
        $order->count = $cart->count;
        $order->cost = $cart->cost;
        $order->status = 1;
        $order->save();
        $cart->cost=0;
        $cart->count=0;
        $cart->save();
        $cartevents = CartEvent::where(['id_user'=>$user,'id_cart'=>$id])->get();
        foreach ($cartevents as $cartevent) {
            $cartevent->id_cart=null;
            $cartevent->id_order=$order->id;
            $cartevent->save();
        }

        return redirect('/posters');
    }

    public function GetOrders(){
        $orders = Order::where(['id_user'=>auth()->id()])->get();

        return view('OrderView', ['orders'=>$orders]);
    }
    public function GetAllOrders(){
        $orders = Order::all();

        return view('OrderView', ['orders'=>$orders]);
    }

    public function OrderChange($id,Request $request){
        $order = Order::find($id);
        $order->status = $request->status;
        $order->save();
        return view('OrderView', ['orders'=>Order::all()]);
    }


}
