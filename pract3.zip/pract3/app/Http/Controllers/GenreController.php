<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Genre;

class GenreController extends Controller
{
    function GetAll() {
        $genres = Genre::all();
        return view('GenreView', ['genres'=>$genres]);
    }

    function Create(Request $request){
        $genre = new Genre();
        $genre->tittle = $request->tittle;
        $genre->save();

        return redirect('/admin/genres');
    }
    function CreateView(){
        return view('CreateGenreView');
    }

    function UpdateView($id){
        $genre = Genre::find($id);
        return view('CreateGenreView', ['genre'=>$genre]);
    }

    function Update($id, Request $request){
        $genre = Genre::find($id);
        $genre->tittle = $request->tittle;
        $genre->save();

        return redirect('/admin/genres');
    }
}
