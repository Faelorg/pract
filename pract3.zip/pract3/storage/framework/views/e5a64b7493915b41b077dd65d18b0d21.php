<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    #map{
        height: 25vw;
    }
</style>
<div class="container d-grid justify-content-center">
    <h1>Где нас найти?</h1>
    <img src="/media/images/map.jpg" id="map" alt="">

    <div>
        <h2>Контактные данные</h2>
        <h4>
            Адресс: г. Москва ул. Пупкина д. 8
        </h4>
        <h4>
            Телефон: +7(905)-963-52-32
        </h4>
        <h4>
            Почта: omega@mail.ru
        </h4>
    </div>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/FindView.blade.php ENDPATH**/ ?>