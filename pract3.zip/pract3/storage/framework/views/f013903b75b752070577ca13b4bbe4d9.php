<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <title>Омега</title>
    <style>
        #logo{
            height: 10vw;
        }
    </style>
</head>
<body>
<header class="container">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="nav-link active" aria-current="page" href="/">
            <img class="navbar-brand" src="/media/images/logo.jpeg" id="logo"/>
            
        </a>
        <a class="nav-link active" aria-current="page" href="/posters">Афиша</a>
        
        <a class="nav-link active" aria-current="page" href="/find">Где нас найти</a>
        <?php if(!auth()->check()): ?>
        <a href="/auth">
            <button class="btn btn-outline-success" type="submit">Войти</button>
        </a>
        <a href="/reg">
            <button class="btn btn-outline-success" type="submit">Зарегистрироваться</button>
        </a>
        <?php else: ?>
        <a href="/logout">
            <button class="btn btn-outline-danger" type="submit">Выйти</button>
        </a>
        <?php endif; ?>
          </div>
        </div>
      </nav>
</header><?php /**PATH C:\OSPanel\domains\efremov\pract3\resources\views/HeaderView.blade.php ENDPATH**/ ?>