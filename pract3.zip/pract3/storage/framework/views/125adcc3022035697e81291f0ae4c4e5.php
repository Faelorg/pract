<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container d-grid justify-content-center">
    <div class="row row-cols-1 row-cols-md-2 g-4">
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Количество <?php echo e($event->count); ?> бил.</h5>
                    <p class="card-text">Стоимость <?php echo e($event->cost); ?> руб.</p>
                    <p class="card-text">
                        <?php if($event->status==1): ?>
                        Новый
                        <?php elseif($event->status==2): ?>
                        Подтвержден
                        <?php elseif($event->status==3): ?>
                        Отменен
                        <?php endif; ?>
                    </p>

                    <?php if(auth()->user()->is_admin): ?>
                    <?php if($event->status == 1): ?>
                        <form action="/admin/orders/<?php echo e($event->id); ?>/save" method="POST">
                            <?php echo csrf_field(); ?>
                            <select name="status" id="">
                                <option value="2">Подтвержден</option>
                                <option value="3">Отменен</option>
                            </select>

                            <button class="btn btn-submit">Сохранить</button>
                        </form>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\pract3\resources\views/OrderView.blade.php ENDPATH**/ ?>