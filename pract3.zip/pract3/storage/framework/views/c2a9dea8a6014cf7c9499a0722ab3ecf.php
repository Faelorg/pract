<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container d-grid justify-content-center">
    Количество: <?php echo e($cart->count); ?> шт.
    <br>
    Общая стоимость: <?php echo e($cart->cost); ?> руб.
    <a href="/cart/<?php echo e($cart->id); ?>/order" class="btn btn-success">Оформить</a>
    <div class="row row-cols-1 row-cols-md-2 g-4">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <a  href="/posters/<?php echo e($event->id); ?>">
                <img src="/media/images/<?php echo e($event->id); ?>.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($event->tittle); ?></h5>
                    <p class="card-text"><?php echo e($event->age); ?>+</p>
                    <p class="card-text"><?php echo e($event->cost); ?> руб.</p>
                    <p class="card-text"><?php echo e($event->date); ?></p>
                    <a href="/cart/<?php echo e($event->id); ?>/remove" class="btn btn-danger">Отменить</a>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\pract3\resources\views/CartView.blade.php ENDPATH**/ ?>