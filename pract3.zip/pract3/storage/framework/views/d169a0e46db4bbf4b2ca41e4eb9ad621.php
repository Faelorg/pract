<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container d-grid justify-content-center">
    <form action="/auth" method="POST">
      <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Логин</label>
          <input name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Пароль</label>
          <input type="password" name="password" class="form-control" minlength="6" id="exampleInputPassword1">
        </div>
        <div class="grid">
            <button  type="submit" class="btn btn-primary col">Войти</button>
            <a class="col" href="/reg">Зарегистрироваться</a>
        </div>
      </form>

      <?php if(isset($error)): ?>
      <?php echo e($error); ?>

      <?php endif; ?>

      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($errorik); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/AuthView.blade.php ENDPATH**/ ?>