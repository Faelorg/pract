<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    a{
        text-decoration: none;
        color: #000;
    }
</style>

<form action="/posters" class="container">
    Сортировать
    <select name="sort">
        <option value="created_at">Дата создания</option>
        <option value="date">Дата показа</option>
        <option value="age">Возраст</option>
    </select>
    <?php if(isset($genres)): ?>
    Фильтр
    <select name="filter" id="">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($filter->id); ?>"><?php echo e($filter->tittle); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php endif; ?>
    <button class="btn btn-submit">Поиск</button>
</form>

<div class="container">
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="card" href="/posters/<?php echo e($event->id); ?>">
            <img src="/media/images/<?php echo e($event->id); ?>.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($event->tittle); ?></h5>
                <p class="card-text"><?php echo e($event->age); ?>+</p>
                <p class="card-text"><?php echo e($event->cost); ?> руб.</p>
                <p class="card-text"><?php echo e($event->date); ?></p>
                <p class="card-text"><?php echo e($genres[$event->id_genre-1]->tittle); ?></p>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\efremov\pract3\resources\views/PosterView.blade.php ENDPATH**/ ?>