<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <a href="/admin/genres">Жанры</a>
    <a href="">Заказы</a>
    <a href="">Постановки</a>
    <a href="">Жанры</a>
    <a href="">Жанры</a>
</div>


<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/PanelView.blade.php ENDPATH**/ ?>