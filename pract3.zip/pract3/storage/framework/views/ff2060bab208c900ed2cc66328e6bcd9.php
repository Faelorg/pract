<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <?php if(isset($genre)): ?>
    <form action="/admin/genres/<?php echo e($genre->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" value="<?php echo e($genre->tittle); ?>" aria-describedby="emailHelp">
        </div>
        <button  type="submit" class="btn btn-primary">Сохранить</button>
    </form>
    <?php else: ?>
    <form action="/admin/genres/create" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <button  type="submit" class="btn btn-primary">Создать</button>
    </form>
    <?php endif; ?>

    <?php if(isset($error)): ?>
    <?php echo e($error); ?>

    <?php endif; ?>

    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($errorik); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>


<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\pract3\resources\views/CreateGenreView.blade.php ENDPATH**/ ?>