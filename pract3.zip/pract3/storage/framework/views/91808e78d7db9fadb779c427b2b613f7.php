<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <?php if(isset($event)): ?>
    <form action="/admin/events/<?php echo e($event->id); ?>/update" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->tittle); ?>" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Дата проведения</label>
            <input name="date" type="date" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->date); ?>" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Возрастной ценз.</label>
            <input name="age" type="number" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->age); ?>" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Цена билета</label>
            <input name="cost" type="number" class="form-control" id="exampleInputEmail1" value="<?php echo e($event->cost); ?>" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <select name="id_genre" value="<?php echo e($event->id_genre); ?>">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->tittle); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button  type="submit" class="btn btn-primary">Сохранить</button>
    </form>
    <?php else: ?>
    <form action="/admin/events/create" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Картинка</label>
            <input name="image" class="form-control" type="file" accept="image/jpeg,image/png" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Дата проведения</label>
            <input name="date" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Возрастной ценз.</label>
            <input name="age" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Цена билета</label>
            <input name="cost" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <select name="id_genre">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->tittle); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button  type="submit" class="btn btn-primary">Создать</button>
    </form>
    <?php endif; ?>

    <?php if(isset($error)): ?>
    <?php echo e($error); ?>

    <?php endif; ?>

    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errorik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($errorik); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>


<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/CreateEventView.blade.php ENDPATH**/ ?>