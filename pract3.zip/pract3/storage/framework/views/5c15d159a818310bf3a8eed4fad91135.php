<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>

#text{
}

</style>
<div class="container">
    <div class="card text-bg-dark">
        <img src="/media/images/<?php echo e($event->id); ?>.jpg" class="card-img" alt="...">
        <div class="" id="text">
            <h5 class="card-title"><?php echo e($event->tittle); ?></h5>
            <p class="card-text">Возраст: <?php echo e($event->age); ?>+</p>
            <p class="card-text">Цена: <?php echo e($event->cost); ?> руб.</p>
            <p class="card-text">Дата показа: <?php echo e($event->date); ?></p>
            <p class="card-text"><small>Жанр: <?php echo e($genres[$event->id_genre-1]->tittle); ?></small></p>
        </div>
    </div>
</div>

<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\efremov\pract3\resources\views/PostView.blade.php ENDPATH**/ ?>