<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div>
    <div id="carouselExample" class="carousel slide">

        <div class="carousel-inner">
            <?php for($i = 0; $i < 5; $i++): ?>
                <?php if($i==1): ?>
                <div class="carousel-item active">
                    <?php else: ?>
                    <div class="carousel-item ">
                    <?php endif; ?>
                    <img src="/media/images/<?php echo e($events[$i]->id); ?>.jpg" class="d-block w-100" alt="...">
                    <div><?php echo e($events[$i]->tittle); ?></div>
            </div>
            <?php endfor; ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Предыдущий</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Следующий</span>
        </button>
    </div>
</div>

<div class="container">
    <h1>Наш девиз четыре слова</h1>
    <h3>Чтоб сгорела наша школа</h3>
</div>


<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/AboutView.blade.php ENDPATH**/ ?>