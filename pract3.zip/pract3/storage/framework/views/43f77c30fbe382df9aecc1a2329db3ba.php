<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($genre->tittle); ?></h5>
              <a href="/admin/genres/<?php echo e($genre->id); ?>/update">
                  <button class="btn btn-success">Изменить</button>
              </a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col">
            <a href="/admin/genres/create">
                <button class="btn btn-primary">
                    <div class="card-body">
                        <div class="card-title h2">+</div>
                    </div>
                </button>
            </a>
        </div>
    </div>
</div>


<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\pract3\resources\views/GenreView.blade.php ENDPATH**/ ?>