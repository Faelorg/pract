    
</body>
<script src="/jquery-3.7.1.min.js"></script>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</html><?php /**PATH C:\OSPanel\domains\localhost\pract3\resources\views/FooterView.blade.php ENDPATH**/ ?>