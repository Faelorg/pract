<?php echo $__env->make('HeaderView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container d-grid justify-content-center">
    <form id="form" action="/reg" method="POST">
      <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Имя</label>
          <input name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Фамилия</label>
          <input name="surname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Отчество</label>
          <input name="patronymic" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Логин</label>
          <input name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Емэйл</label>
          <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Пароль</label>
          <input type="password" name="password" class="form-control" minlength="6" id="exampleInputPassword1">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Повторите пароль</label>
          <input type="password" class="form-control" id="exampleInputPassword1">
        </div>
        <div class="mb-3 form-check">
          <input type="checkbox" name="rules" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Согласен с правилами</label>
        </div>
        <div class="grid">
            <button  type="submit" class="btn btn-primary col">Зарегистрироваться</button>
            <a class="col" href="/auth">Войти</a>
        </div>

        <?php if($errors->any()): ?>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($error); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(isset($error_text)): ?>
        <?php echo e($error_text); ?>

        <?php endif; ?>
      </form>

      <script>
        document.getElementById("form").addEventListener("submit", function(event) {
            let password = document.querySelectorAll('#exampleInputPassword1')
            if (password[0].value != password[1].value) {
                event.preventDefault(); // отменяет обновление страницы
                alert('Пароли должны совпадатать')
            }
        });
      </script>
</div>
<?php echo $__env->make('FooterView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\efremov\pract3\resources\views/RegView.blade.php ENDPATH**/ ?>