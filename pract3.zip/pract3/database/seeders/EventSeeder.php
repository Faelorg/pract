<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;

class EventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i=0; $i < 50; $i++) {
            DB::table('events')->insert([
                'tittle' => Str::random(10),
                'date' =>Carbon::now()->subDays(30)->addDays(30),
                'age' => rand(0,18),
                'cost' => rand(250,500),
                'count' => rand(0,15),
                'id_genre'=>rand(1,3),
            ]);
        }
    }
}
