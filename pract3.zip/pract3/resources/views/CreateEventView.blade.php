@include('HeaderView')

<div class="container">
    @isset($event)
    <form action="/admin/events/{{ $event->id }}/update" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" value="{{ $event->tittle }}" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Дата проведения</label>
            <input name="date" type="date" class="form-control" id="exampleInputEmail1" value="{{ $event->date }}" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Возрастной ценз.</label>
            <input name="age" type="number" class="form-control" id="exampleInputEmail1" value="{{ $event->age }}" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Цена билета</label>
            <input name="cost" type="number" class="form-control" id="exampleInputEmail1" value="{{ $event->cost }}" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <select name="id_genre" value="{{ $event->id_genre }}">
                @foreach ($genres as $genre)
                <option value="{{ $genre->id }}">{{ $genre->tittle }}</option>
                @endforeach
            </select>
        </div>
        <button  type="submit" class="btn btn-primary">Сохранить</button>
    </form>
    @else
    <form action="/admin/events/create" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Картинка</label>
            <input name="image" class="form-control" type="file" accept="image/jpeg,image/png" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Дата проведения</label>
            <input name="date" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Возрастной ценз.</label>
            <input name="age" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Количество билетов.</label>
            <input name="count" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Цена билета</label>
            <input name="cost" type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
            <select name="id_genre">
                @foreach ($genres as $genre)
                <option value="{{ $genre->id }}">{{ $genre->tittle }}</option>
                @endforeach
            </select>
        </div>
        <button  type="submit" class="btn btn-primary">Создать</button>
    </form>
    @endif

    @isset($error)
    {{$error}}
    @endisset

    @if($errors->any())
    @foreach ($errors->all() as $errorik)
        {{$errorik}}
    @endforeach
    @endif
</div>


@include('FooterView')
