@include('HeaderView')

<style>

#text{
}

</style>
<div class="container">
    <div class="card text-bg-dark">
        <img src="/media/images/{{$event->id}}.jpg" class="card-img" alt="...">
        <div class="" id="text">
            <h5 class="card-title">{{$event->tittle}}</h5>
            <p class="card-text">Возраст: {{$event->age}}+</p>
            <p class="card-text">Цена: {{$event->cost}} руб.</p>
            <p class="card-text">Дата показа: {{$event->date}}</p>
            <p class="card-text"><small>Жанр: {{ $genres[$event->id_genre-1]->tittle}}</small></p>
        </div>
    </div>
</div>

@include('FooterView')