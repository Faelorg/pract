@include('HeaderView')

<div class="container">
    <a href="/admin/genres">Жанры</a>
    <a href="/admin/orders">Заказы</a>
    <a href="">Постановки</a>
</div>


@include('FooterView')
