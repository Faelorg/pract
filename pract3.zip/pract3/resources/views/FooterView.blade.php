    
</body>
<script src="/jquery-3.7.1.min.js"></script>
<script src="/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</html>