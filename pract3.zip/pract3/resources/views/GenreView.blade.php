@include('HeaderView')

<div class="container">
    <div class="row row-cols-1 row-cols-md-3 g-4">
        @foreach ($genres as $genre)
        <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">{{ $genre->tittle }}</h5>
              <a href="/admin/genres/{{ $genre->id }}/update">
                  <button class="btn btn-success">Изменить</button>
              </a>
            </div>
          </div>
        </div>
        @endforeach

        <div class="col">
            <a href="/admin/genres/create">
                <button class="btn btn-primary">
                    <div class="card-body">
                        <div class="card-title h2">+</div>
                    </div>
                </button>
            </a>
        </div>
    </div>
</div>


@include('FooterView')
