@include('HeaderView')
<div class="container d-grid justify-content-center">
    <div class="row row-cols-1 row-cols-md-2 g-4">
    @foreach ($orders as $event)
        <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Количество {{$event->count}} бил.</h5>
                    <p class="card-text">Стоимость {{$event->cost}} руб.</p>
                    <p class="card-text">
                        @if($event->status==1)
                        Новый
                        @elseif($event->status==2)
                        Подтвержден
                        @elseif($event->status==3)
                        Отменен
                        @endif
                    </p>

                    @if(auth()->user()->is_admin)
                    @if($event->status == 1)
                        <form action="/admin/orders/{{$event->id}}/save" method="POST">
                            @csrf
                            <select name="status" id="">
                                <option value="2">Подтвержден</option>
                                <option value="3">Отменен</option>
                            </select>

                            <button class="btn btn-submit">Сохранить</button>
                        </form>
                    @endif
                    @endif
                </div>
        </div>
        @endforeach
    </div>
    </div>
</div>
@include('FooterView')
