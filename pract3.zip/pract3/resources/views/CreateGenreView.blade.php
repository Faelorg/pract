@include('HeaderView')

<div class="container">
    @isset($genre)
    <form action="/admin/genres/{{ $genre->id }}/update" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" value="{{ $genre->tittle }}" aria-describedby="emailHelp">
        </div>
        <button  type="submit" class="btn btn-primary">Сохранить</button>
    </form>
    @else
    <form action="/admin/genres/create" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Название</label>
            <input name="tittle" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <button  type="submit" class="btn btn-primary">Создать</button>
    </form>
    @endif

    @isset($error)
    {{$error}}
    @endisset

    @if($errors->any())
    @foreach ($errors->all() as $errorik)
        {{$errorik}}
    @endforeach
    @endif
</div>


@include('FooterView')
