@include('HeaderView')

<div class="container d-grid justify-content-center">
    <form action="/auth" method="POST">
      @csrf
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Логин</label>
          <input name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Пароль</label>
          <input type="password" name="password" class="form-control" minlength="6" id="exampleInputPassword1">
        </div>
        <div class="grid">
            <button  type="submit" class="btn btn-primary col">Войти</button>
            <a class="col" href="/reg">Зарегистрироваться</a>
        </div>
      </form>

      @isset($error)
      {{$error}}
      @endisset

      @if($errors->any())
      @foreach ($errors->all() as $errorik)
          {{$errorik}}
      @endforeach
      @endif
</div>
@include('FooterView')