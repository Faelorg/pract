@include('HeaderView')
<div class="container d-grid justify-content-center">
    Количество: {{$cart->count}} шт.
    <br>
    Общая стоимость: {{$cart->cost}} руб.
    <a href="/cart/{{$cart->id}}/order" class="btn btn-success">Оформить</a>
    <div class="row row-cols-1 row-cols-md-2 g-4">
    @foreach ($events as $event)
        <div class="card">
            <a  href="/posters/{{$event->id}}">
                <img src="/media/images/{{$event->id}}.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$event->tittle}}</h5>
                    <p class="card-text">{{$event->age}}+</p>
                    <p class="card-text">{{$event->cost}} руб.</p>
                    <p class="card-text">{{$event->date}}</p>
                    <a href="/cart/{{$event->id}}/remove" class="btn btn-danger">Отменить</a>
                </div>
            </a>
        </div>
        @endforeach
    </div>
</div>
@include('FooterView')
