@include('HeaderView')
<style>
    a{
        text-decoration: none;
        color: #000;
    }
</style>

<form action="/posters" class="container">
    Сортировать
    <select name="sort">
        <option value="null"></option>
        <option value="created_at">Дата создания</option>
        <option value="date">Дата показа</option>
        <option value="age">Возраст</option>
    </select>
    @isset($genres)
    Фильтр
    <select name="filter" id="">
        <option value="null"></option>
        @foreach($genres as $filter)
        <option value="{{$filter->id}}">{{$filter->tittle}}</option>
        @endforeach
    </select>
    @endisset
    <button class="btn btn-primary">Поиск</button>
</form>

<div class="container">
    @if (auth()->check())
    @if (auth()->user()->is_admin)
    <div class="d-flex justify-content-end">
        <a href="/admin/events/create" class="btn btn-success">Создать</a>
    </div>
    @endif
    @endif
    <div class="row row-cols-1 row-cols-md-2 g-4">
        @foreach ($events as $event)
        <div class="card">
            <a  href="/posters/{{$event->id}}">
                <img src="/media/images/{{$event->id}}.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">{{$event->tittle}}</h5>
                    <p class="card-text">{{$event->age}}+</p>
                    <p class="card-text">{{$event->cost}} руб.</p>
                    <p class="card-text">{{$event->date}}</p>
                    <p class="card-text">{{$event->count}} бил.</p>
                    <p class="card-text">{{ $genres[$event->id_genre-1]->tittle}}</p>

                </div>
            </a>
            @if (auth()->check())
            @if (auth()->user()->is_admin)
            <div class="grid">
                <a href="/admin/events/{{ $event->id }}/update" class="btn btn-primary col">Изменить</a>
                <a href="/admin/events/{{ $event->id }}/delete" class="btn btn-danger col">Удалить</a>
            </div>
            @else
            @if($event->count>0)
            <div class="d-flex justify-content-end">
                <a href="/posters/{{$event->id}}/add" class="btn btn-success">Купить</a>
            </div>
            @endif
            @endif
            @endif
        </div>
        @endforeach
    </div>
</div>
@include('FooterView')
