<?php

use App\Http\Controllers\EventController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\CartController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [EventController::class, 'Slider']);

Route::get('/find', function () {
    return view('FindView');
});

Route::get('/reg', function () {
    return view('RegView');
});

Route::post('/reg', [UserController::class,'Reg']);

Route::get('/auth', function () {
    return view('AuthView');
});

Route::post('/auth', [UserController::class,'Auth']);
Route::get('/logout', [UserController::class,'Logout']);

Route::get('/posters',[EventController::class,'GetAll']);
Route::get('/posters/{id}',[EventController::class,'GetById']);
Route::get('/posters/{id}/add',[CartController::class,'AddToCart']);

Route::get('/cart',[CartController::class,'GetAll']);
Route::get('/cart/{id}/remove',[CartController::class,'RemoveToCart']);
Route::get('/cart/{id}/order',[CartController::class,'CreateOrder']);
Route::get('/order',[CartController::class,'GetOrders']);

Route::group(['prefix'=>'/admin','middleware'=>['admin']],(function () {
    Route::get('/', function () {
        return view('PanelView');
    });
    Route::get('/orders',[CartController::class,'GetAllOrders']);
    Route::post('/orders/{id}/save',[CartController::class,'OrderChange']);
    Route::get('/genres', [GenreController::class,'GetAll']);
    Route::get('/genres/create', [GenreController::class,'CreateView']);
    Route::post('/genres/create', [GenreController::class,'Create']);
    Route::get('/genres/{id}/update', [GenreController::class,'UpdateView']);
    Route::post('/genres/{id}/update', [GenreController::class,'Update']);

    Route::get('/events', [EventController::class,'GetAll']);
    Route::get('/events/create', [EventController::class,'CreateView']);
    Route::post('/events/create', [EventController::class,'Create']);
    Route::get('/events/{id}/update', [EventController::class,'UpdateView']);
    Route::post('/events/{id}/update', [EventController::class,'Update']);
    Route::get('/events/{id}/delete', [EventController::class,'Delete']);
}));
